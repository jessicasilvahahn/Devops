
*********
Credits
*********

- Philippe Biondi is Scapy's author. He has also written most of the documentation.
- Pierre Lalet, Gabriel Potter, Guillaume Valadon are the current most active maintainers and contributors.
- Fred Raynal wrote the chapter on building and dissecting packets.
- Peter Kacherginsky contributed several tutorial sections, one-liners and recipes.
- Dirk Loss integrated and restructured the existing docs to make this book.

:mod:`panoramisk.fast_agi` - Fast AGI
=====================================

An API to create Fast AGI applications

API
---

.. automodule:: panoramisk.fast_agi

.. autoclass:: Application
   :members:


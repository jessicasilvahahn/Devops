=========================
:mod:`panoramisk.message`
=========================

.. automodule:: panoramisk.message

.. autoclass:: Message
   :members:

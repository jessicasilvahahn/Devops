=========================
:mod:`panoramisk.actions`
=========================

.. automodule:: panoramisk.actions

.. autoclass:: Action
   :members:

.. autoclass:: Command
   :members:


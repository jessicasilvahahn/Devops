
Developer
---------

When developping with Panoramisk you might find useful to see precisely the requests/responses
going in and out through the AMI interface.

You can use Tcpdump, Wireshark which might be advised on a production/loaded system, but for
some quick test on your local machine you can use netcat to inspect traffic simple.

The shell script `netcat-middleman.sh` help you to log your incoming and outgoing traffic.
